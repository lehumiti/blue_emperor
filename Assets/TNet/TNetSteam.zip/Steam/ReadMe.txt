----------------------------------------------
   TNet's Steamworks Integration Example
Copyright (c) 2019 Tasharen Entertainment Inc.
----------------------------------------------

1. Open Steam.cs and set the appID value to your own game's.
2. Open the [0. Menu] scene.
3. Create a new game object and attach the Steam script to it and save the scene.

You can now build the application, choose the "Start a LAN Server" option, and it will be possible for your friends
to right-click your name on their friends list and choose "Join Game". Doing so will launch the example you've built
and will automatically connect to them. All communication will be sent through Steamworks, but your game's code will
continue using TNet as if nothing has changed.

To connect to a Steam friend manually, call Steam.Connect("steamID"), where 'steamID' is their Steam ID, such as:
Steam.Connect("76561198012345678")

To control when it will be possible to join, check Steam.OnConnect: it simply calls AllowFriendsToJoin(true).
You can remove it from there, and call Steam.AllowFriendsToJoin(true/false) yourself as desired instead.

If you want to limit who can join (such as only friends, not friends-of-friends), check the Steam.EnableNetworkingSupport
function (~line 316 of Steam.cs).